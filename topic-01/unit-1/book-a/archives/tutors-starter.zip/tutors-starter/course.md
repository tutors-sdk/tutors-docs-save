# Tutors Starter Three

A short description of the course. Normally this will not be visible, unless the course is aggregated into a portfolio of modules