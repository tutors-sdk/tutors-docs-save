Podcast

The HDip course team discuss approaching IT as an Adult Learner